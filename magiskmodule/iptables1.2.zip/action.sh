#!/system/bin/sh

MODDIR=${0%/*}
STATUS_FILE="$MODDIR/status"
IPTABLES="/system/bin/iptables"
IP6TABLES="/system/bin/ip6tables"

# 切换状态
if [ "$(cat "$STATUS_FILE")" = "enabled" ]; then
    echo "disabled" > "$STATUS_FILE"
    $IPTABLES -F
    $IP6TABLES -F
    echo "Firewall DISABLED"
else
    echo "enabled" > "$STATUS_FILE"
    if [ -f "$MODDIR/config/ip_list.txt" ]; then
        while read -r ip; do
            ip=$(echo "$ip" | sed 's/#.*//' | xargs)
            [ -z "$ip" ] && continue
            if [[ "$ip" =~ : ]]; then
                $IP6TABLES -A INPUT -s "$ip" -j DROP
                $IP6TABLES -A OUTPUT -d "$ip" -j DROP
            else
                $IPTABLES -A INPUT -s "$ip" -j DROP
                $IPTABLES -A OUTPUT -d "$ip" -j DROP
            fi
        done < "$MODDIR/config/ip_list.txt"
        echo "Firewall ENABLED"
    else
        echo "IP list not found"
    fi
fi