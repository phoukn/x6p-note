#!/system/bin/sh

MODDIR=${0%/*}
IP_LIST="$MODDIR/config/ip_list.txt"
STATUS_FILE="$MODDIR/status"

# 设置iptables路径
IPTABLES="/system/bin/iptables"
IP6TABLES="/system/bin/ip6tables"

# 初始化状态文件
[ -f "$STATUS_FILE" ] || echo "enabled" > "$STATUS_FILE"

# 读取当前状态
CURRENT_STATUS=$(cat "$STATUS_FILE")

# 等待系统启动
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; done
sleep 3  # 额外等待网络

# 清除旧规则
$IPTABLES -F
$IP6TABLES -F

# 应用规则（仅当启用状态）
if [ "$CURRENT_STATUS" = "enabled" ] && [ -f "$IP_LIST" ]; then
    while read -r ip; do
        ip=$(echo "$ip" | sed 's/#.*//' | xargs)
        [ -z "$ip" ] && continue
        if [[ "$ip" =~ : ]]; then
            $IP6TABLES -A INPUT -s "$ip" -j DROP
            $IP6TABLES -A OUTPUT -d "$ip" -j DROP
        else
            $IPTABLES -A INPUT -s "$ip" -j DROP
            $IPTABLES -A OUTPUT -d "$ip" -j DROP
        fi
    done < "$IP_LIST"
fi