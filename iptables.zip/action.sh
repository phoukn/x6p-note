#!/system/bin/sh

MODDIR=${0%/*}
ACTION_LOG="$MODDIR/action.log"
STATUS_FILE="$MODDIR/status"
IPTABLES="/system/bin/iptables"
IP6TABLES="/system/bin/ip6tables"

# 记录操作
echo "==== Action Button Clicked ====" > "$ACTION_LOG"
date >> "$ACTION_LOG"

# 读取当前状态
CURRENT_STATUS=$(cat "$STATUS_FILE")
echo "Current status: $CURRENT_STATUS" >> "$ACTION_LOG"

# 切换状态
if [ "$CURRENT_STATUS" = "enabled" ]; then
    # 当前是开启状态，切换到关闭
    echo "Switching to disabled..." >> "$ACTION_LOG"
    echo "disabled" > "$STATUS_FILE"
    
    # 清除规则
    $IPTABLES -F
    $IP6TABLES -F
    echo "Firewall rules cleared." >> "$ACTION_LOG"
    
    # 在Magisk Manager中显示消息
    echo "Firewall DISABLED"
else
    # 当前是关闭状态，切换到开启
    echo "Switching to enabled..." >> "$ACTION_LOG"
    echo "enabled" > "$STATUS_FILE"
    
    # 应用规则
    if [ -f "$MODDIR/config/ip_list.txt" ]; then
        while read -r ip; do
            ip=$(echo "$ip" | sed 's/#.*//' | xargs)
            [ -z "$ip" ] && continue
            if [[ "$ip" =~ : ]]; then
                $IP6TABLES -A INPUT -s "$ip" -j DROP
                $IP6TABLES -A OUTPUT -d "$ip" -j DROP
            else
                $IPTABLES -A INPUT -s "$ip" -j DROP
                $IPTABLES -A OUTPUT -d "$ip" -j DROP
            fi
        done < "$MODDIR/config/ip_list.txt"
        echo "Firewall rules applied." >> "$ACTION_LOG"
        echo "Firewall ENABLED"
    else
        echo "IP list not found. Cannot enable." >> "$ACTION_LOG"
        echo "IP list not found"
    fi
fi

echo "==== Action Completed ====" >> "$ACTION_LOG"
date >> "$ACTION_LOG"