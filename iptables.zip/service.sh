#!/system/bin/sh

MODDIR=${0%/*}
IP_LIST="$MODDIR/config/ip_list.txt"
STATUS_FILE="$MODDIR/status"
LOG="$MODDIR/firewall.log"

# 确保日志文件存在
echo "==== Starting Firewall Service ====" > "$LOG"
echo "Module path: $MODDIR" >> "$LOG"

# 设置iptables绝对路径
IPTABLES="/system/bin/iptables"
IP6TABLES="/system/bin/ip6tables"

# 初始化状态文件（如果不存在）
if [ ! -f "$STATUS_FILE" ]; then
    echo "enabled" > "$STATUS_FILE"
fi

# 读取当前状态
CURRENT_STATUS=$(cat "$STATUS_FILE")
echo "Current status: $CURRENT_STATUS" >> "$LOG"

# 等待系统完全启动
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done

# 额外等待网络服务
sleep 10

# 清空旧规则
$IPTABLES -F
$IP6TABLES -F

# 如果状态为启用，则添加规则
if [ "$CURRENT_STATUS" = "enabled" ]; then
    echo "Applying firewall rules..." >> "$LOG"
    if [ -f "$IP_LIST" ]; then
        while read -r ip; do
            # 跳过注释和空行
            ip=$(echo "$ip" | sed 's/#.*//' | xargs)
            [ -z "$ip" ] && continue
            
            echo "Blocking IP: $ip" >> "$LOG"
            
            if [[ "$ip" =~ : ]]; then  # IPv6
                $IP6TABLES -A INPUT -s "$ip" -j DROP
                $IP6TABLES -A OUTPUT -d "$ip" -j DROP
            else  # IPv4
                $IPTABLES -A INPUT -s "$ip" -j DROP
                $IPTABLES -A OUTPUT -d "$ip" -j DROP
            fi
        done < "$IP_LIST"
    else
        echo "IP list not found!" >> "$LOG"
    fi
else
    echo "Firewall is disabled. Skipping rule application." >> "$LOG"
fi

# 验证规则
echo "==== Current iptables Rules ====" >> "$LOG"
$IPTABLES -L -n -v >> "$LOG"
echo "==== Current ip6tables Rules ====" >> "$LOG"
$IP6TABLES -L -n -v >> "$LOG"

echo "Firewall service completed at $(date)" >> "$LOG"